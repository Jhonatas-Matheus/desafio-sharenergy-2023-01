interface IRefreshTokenResponse {
  token: string;
}
export { IRefreshTokenResponse };
