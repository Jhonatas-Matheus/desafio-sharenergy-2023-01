import { IClient, IClientModel } from "../../../entities/Clients";

type ICreateClientDTO = IClient;
type ICreatedClientDTO = IClientModel;
export { ICreateClientDTO, ICreatedClientDTO };
