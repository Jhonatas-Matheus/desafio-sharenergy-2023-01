import { IClientModel } from "../../../entities/Clients";

type IGetAllClientsResponse = IClientModel[];
export { IGetAllClientsResponse };
