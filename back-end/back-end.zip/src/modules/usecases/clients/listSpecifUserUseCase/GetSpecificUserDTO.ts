import { IClientModel } from "../../../entities/Clients";

type IResponseSpecificUserDTO = IClientModel;

export { IResponseSpecificUserDTO };
